'use strict';

angular.module('app', []).controller('appController', function ($scope) {

  var ctrl = this;

  var DEMO_EVENTS = [
    { value: 100, time: moment() },
    { value: 155, time: moment() },
    { value: 83, time: moment() },
    { value: 211, time: moment().subtract(1, 'day') },
    { value: 138, time: moment().subtract(1, 'day') },
    { value: 55, time: moment().subtract(1, 'day') },
    { value: 183, time: moment().subtract(2, 'day') },
    { value: 103, time: moment().subtract(2, 'day') },
    { value: 98, time: moment().subtract(3, 'day') }
  ];

  ctrl.helloWorld = 'Hello World vikki!'; // Dashboard welcome message (this can be deleted)

  // Add your AngularJS controller logic here

  ctrl.dasBoard = "Dashboard";
  ctrl.date ="Mon, 1 Jan 2020";
  ctrl.event1="Total blood sugar events";
  ctrl.event2="Average blood sugar";
  ctrl.event3="Events between 70 and 180";
  ctrl.event ="events";
  ctrl.mg ="mg/dL";
  ctrl.percnt="80%";
  ctrl.percnt1="75%";
  ctrl.previousDay = "Previous day";
  ctrl.no1 = 3;
  ctrl.no2 =123;
  ctrl.no3 =150;
});
