# Center Front-end Code Project

Code project for prospective front-end / full-stack developer hires 😍

Please follow the instructions in `INSTRUCTIONS.md`
